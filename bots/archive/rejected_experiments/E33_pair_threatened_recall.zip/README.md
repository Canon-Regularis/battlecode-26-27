# E33 — Threatened linked-pair recall

E33 starts from E05A and keeps its draft, split farming, clearing, capture, banking and ordinary 35% retreat unchanged. One extra condition applies only to Cassi or Issac when bag-empty and in the 35–50% health band: recall early only if a living visible enemy is within four tiles.

**Hypothesis:** E06's unconditional early recall changed the whole-map pressure results but raised linked-pair deaths. Restricting that early recall to a visible nearby threat may preserve farm time while still protecting a weak linked unit from an immediate fight.

## Result — rejected

At `--fuel 100000`, E33 completed the four-map/both-side pilot against E05A, G2, the carrier hunter and altar denial with zero faults. It went 5/8 against E05A (7,040 submitted / 7,744 collected; 145 deaths), but only 4/8 against G2 (6,806 submitted), 2/8 against the hunter (7,246 submitted), and 3/8 against altar denial (5,486 submitted). The matched G2 totals were 7,132, 7,878 and 6,004 submissions respectively. The threat gate did not improve the relevant pressure suites enough to justify expansion. Reject and archive; no per-turn fuel savings were measured.

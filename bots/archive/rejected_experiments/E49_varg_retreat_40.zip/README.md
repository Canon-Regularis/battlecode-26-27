# E49 — Varg-only 40% low-health retreat (rejected)

E49 starts from E41. Only Varg's empty/loaded low-health recall threshold rises to 40%; all other champions remain at 35%. The trigger was motivated by an E41 Packs replay where Varg had 360/1,000 health, no gems and died before the next sample, despite the 35% threshold.

The build completed, then E49 ran at `--fuel 100000` (2,500,000 Python fuel) on all nine maps and both sides against the carrier-hunter and altar-denial proxies (36 matches, zero faults). The four-map initial pilot looked positive versus E41, but the full map suite did not preserve hunter results or E41's altar net.

| Opponent | E49 wins | E49 submitted / conceded | Net | Deaths | Reference |
|---|---:|---:|---:|---:|---|
| Carrier hunter | 4/18 | 12,208 / 17,835 | -5,627 | 304 | G2: 7/18, 14,547 / 16,058, net -1,511, 265 deaths |
| Altar denial | 9/18 | 12,634 / 13,097 | -463 | 254 | E41: 9/18, 12,974 / 12,557, net +417, 262 deaths |

E49 lost three hunter wins and 4,116 net gems relative to G2's matched baseline. It tied E41's altar win count but had an 880-gem worse net. The threshold is therefore not a broad survival fix; the promising four-map pilot did not generalize. Reject it, keep G2 canonical and E41 only as an unpromoted altar specialist. Source and JSONs are archived at `bots/archive/rejected_experiments/E49_varg_retreat_40.zip`; the 36 replays remain under `replays/E49_varg_retreat_40/`.

# E05B — Cassi & Issac / Varg / Vendetta roster challenger

Controlled roster experiment based on the user's current leaderboard observation. Gameplay files are copied from the G2 champion unchanged; only draft priority differs. Three-pick maps choose Cassi & Issac, Varg, and Vendetta (four acting units). Additional selections prefer Stellar and Tavi.

Hypothesis: the extra Cassi & Issac body combines with Varg's grouped-camp splash and Vendetta's high melee damage/reset passive. Counterargument: the pair's linked-death risk and melee exposure may erase their coverage advantage.

This is an unpromoted challenger. Compare both sides across maps against G2 and record score, wins, deaths, faults, and submitted-versus-collected gems before any promotion decision.

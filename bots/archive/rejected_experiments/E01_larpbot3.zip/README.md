# LARPBOT3 challenger

Unpromoted challenger copied from G2. E01 adds a soft exclusion for camps near visible living teammates to reduce duplicate farming/capture assignments. If all available goals are excluded, it retains the original choices. The canonical `bots/larpbot` remains unchanged.

See `../../larpbot/EVOLUTION_LOG.md` and `../../larpbot/EVOLUTION_STATE.md` for the hypothesis and evaluation plan. Build with `cambc build bots/challengers/larpbot3` from the repository root.

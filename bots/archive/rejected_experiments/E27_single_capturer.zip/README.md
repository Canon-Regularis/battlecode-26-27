# E27 — one capturer per cleared camp group

E27 starts from G2. When a group is in `RewardAvailable` state, one allied occupant remains to complete its fixed five-round capture; other allies already on the group, or approaching it, choose another available camp. If multiple allies occupy the group, the lowest engine handle stays. The rule does not check whether the occupant carries gems, even though G2's immediate-bank behavior makes a loaded occupant leave. All other draft, combat, banking, retreat and navigation rules are unchanged.

## Results

Built successfully. The full matrix covers nine maps, both sides, and three opponents (54 matches total), at 2,500,000 fuel per turn. All matches completed with zero bot faults.

| Opponent | E27 wins | E27 submitted / collected | Other team submitted / collected | Deaths E27 / other team |
|---|---:|---:|---:|---:|
| G2 | 10/18 | 15,990 / 17,080 | 16,069 / 16,868 | 273 / 244 |
| Carrier hunter | 7/18 | 15,242 / 17,158 | 16,851 / 17,710 | 314 / 259 |
| Altar denial | 11/18 | 13,204 / 14,990 | 11,083 / 12,548 | 244 / 189 |

Matched G2 full baselines against the pressure proxies were 6/18 and 15,461 submitted / 16,614 collected versus the carrier hunter, and 9/18 and 13,437 / 14,790 versus altar denial. E27 gains proxy wins, but submits 219 fewer gems against the hunter and 233 fewer against altar denial; deaths also increase. In its G2 head-to-head it wins two more maps but submits 79 fewer gems and records 29 more deaths.

Champion statistics show that the rule changes payout distribution: across the G2 matrix, Varg collected 7,280 gems for E27 versus 4,946 for G2, while Tavi collected 1,260 versus G2's 2,039. The rule may also turn empty allies away from a group whose loaded occupant immediately leaves to bank. E27 remains unpromoted; E28 tests that specific handoff condition.

Raw statistics are in `results/`; replays are under `replays/E27_single_capturer/`.

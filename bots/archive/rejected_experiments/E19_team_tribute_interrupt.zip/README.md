# E19 — Nearby teammate tribute interrupt

E19 is E18's conditional lock policy, but any champion may buy one altar lock when at spawn (or, for Tavi, at her remote shop). Any holder may use it to cancel a visible enemy tribute of at least 20 gems when within two tiles of its altar.

This tests whether distributing a low-cost interrupt to the champions already near enemy altars works better than relying on Tavi alone. The lock purchase competes with strength upgrades; no farm or movement rule changed. Status: unpromoted challenger.

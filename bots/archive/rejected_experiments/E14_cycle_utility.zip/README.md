# E14 — Simple cycle utility

E14 keeps G2's draft, combat, shopping, retreat, and banking decisions. Its only gameplay change is camp selection: it picks one group using a lightweight estimate of gems per full loop (approach, clear, capture, return toward an altar, and channel), then routes only toward that group's spawn tiles.

The estimate uses cached group reward and base health plus current champion strength. Travel uses Chebyshev distance to group bounds, so it is cheap and deliberately approximate; it does not model walls, enemy pressure, or gold value. This is an experiment in whether a small value-per-cycle rule improves gem throughput without making the policy expensive.

Status: unpromoted challenger. G2 remains canonical.

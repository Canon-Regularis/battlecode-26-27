# E07 — Meta pair high-risk bag recall

Starting point: E05A (`meta_cassi_stellar_tavi`), with identical draft and all policy unchanged except one rule.

**Observation:** In E05A, Cassi and Issac collected 5,428 gems and submitted 4,628 over 18 fixed map/side matches. The 800-gem difference is consistent with unsecured bags, but aggregate stats cannot assign its cause.

**Hypothesis:** Because either linked unit's death kills both and drops both bags, a Cassi/Issac carrying at least 100 gems at no more than 50% health should recall to preserve the bag, unless an unlocked altar is already within submit range. Recall retains gems. This deliberately tests a rare, critical-health case to limit lost farming turns.

**Counterargument:** Recall takes five owner turns (three with Home), can be interrupted by damage or stun, and may sacrifice a faster altar route. The 50% threshold may trigger too often or still act too late.

**Evaluation:** build and run all nine maps from both sides against G2 with 2,500,000 fuel. Compare against E05A's same roster and base policy. Track wins, secured gems, collected-minus-submitted gap, deaths, and faults. No promotion without broader opponent coverage.

# E08 — Rally and escort rich carriers

Starting point: E05A's Cassi & Issac / Stellar / Tavi draft and G2 gameplay policy.

**Observation:** The user's current meta read is that leading teams split units for resource gathering, then regroup to score and to enter dangerous areas. Our E05 roster tests used independent existing objectives and did not test this behavior.

**Hypothesis:** When a visible teammate carries at least 100 gems and is either near an altar or has an enemy within five tiles, empty-bag allies should move to an adjacent tile to escort them. An escort attacks a visible enemy in range near the carrier first. The regroup ends when the bag is banked or the carrier leaves local vision; normal camp routing then resumes.

**Counterargument:** Personal vision is not shared. This only coordinates once the carrier is locally visible; multiple escorts may idle or abandon profitable camps. The visible-threat condition may arrive too late, while the altar-radius condition may be overbroad.

**Evaluation:** build locally, then compare on both sides across all nine maps at 2,500,000 fuel against G2 and the unchanged E05A roster. Track wins, submitted/collected gems, deaths, and faults. This tests an experimentally bounded rally rule, not full global coordination. Do not promote from a single deterministic matrix.

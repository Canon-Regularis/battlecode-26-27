# E18 — Tavi's conditional tribute interrupt

E18 keeps G2's farming, banking and combat. Tavi buys one altar lock when she can and has none, then uses it only when a visible enemy is actively tributing at least 20 gems, the enemy is beside an unlocked altar, and Tavi is within lock range.

The lock costs 10g and cancels a tribute channel. This tests whether one cheap, directly observed denial action can repay its small upgrade delay without changing the farming routes. Status: unpromoted challenger.

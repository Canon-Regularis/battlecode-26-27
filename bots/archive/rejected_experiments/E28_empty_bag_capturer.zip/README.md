# E28 — empty-bag capture owner

E28 starts from E27. It applies the one-capturer rule only when an allied occupant has an empty gem bag. G2's normal immediate-bank behavior sends loaded allies away, so they do not cause other empty farmers to abandon the capture. When several empty-bag allies occupy the group, the lowest engine handle stays.

This is a four-map pilot (Corners, Interlock, Lanes, Packs), both sides, against G2 and the carrier-hunter and altar-denial proxies (24 matches). All used 2,500,000 fuel per turn and completed with zero reported faults. The exported JSON statistics are byte-for-byte identical to E27 on all 24 shared map/side/opponent cases, so this bag-state refinement had no observable effect. Do not expand it to a full matrix.

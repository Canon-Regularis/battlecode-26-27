"""Tiny shared-memory beacon for escorting one rich gem carrier."""

import cambc
from cambc import game_map


MARKER = 255
SLOT_COUNT = 6
MIN_CARRIER_GEMS = 1
ALERT_SLOT = 5
ALERT_TTL = 2


def _read_slots():
    slots = bytearray(min(SLOT_COUNT, cambc.shared_memory.size()))
    cambc.shared_memory.read(0, slots)
    return slots


def update(me, slot):
    """Publish carrier position and a short-lived confirmed-danger alert."""
    if slot is None or slot >= SLOT_COUNT or cambc.shared_memory.size() < 8:
        return
    slots = _read_slots()
    carrying = me.is_alive() and me.gem_count() >= MIN_CARRIER_GEMS
    if carrying:
        position = me.position()
        if not (0 <= position.x < 255 and 0 <= position.y < 255):
            return
        for index in range(ALERT_SLOT):
            if slots[index] == MARKER:
                slots[index] = 0
        slots[slot] = MARKER
        cambc.shared_memory.write(0, slots)
        cambc.shared_memory.write(6, bytes((position.x, position.y)))
    elif slots[slot] == MARKER:
        slots[slot] = 0
        cambc.shared_memory.write(0, slots)

    slots = _read_slots()
    carrier_slot = next((i for i in range(ALERT_SLOT)
                         if slots[i] == MARKER), None)
    if carrier_slot is None:
        return
    position = bytearray(2)
    cambc.shared_memory.read(6, position)
    carrier_position = cambc.Vec2(position[0], position[1])
    for enemy in cambc.vision.champions(cambc.Team.ENEMY):
        try:
            if (enemy.is_visible() and enemy.health() > 0
                    and enemy.position().chebyshev_distance(carrier_position) <= 5):
                slots[ALERT_SLOT] = cambc.round_number() % 250 + 1
                cambc.shared_memory.write(ALERT_SLOT, bytes((slots[ALERT_SLOT],)))
                return
        except cambc.Error:
            continue


def target(slot):
    """Read the current carrier's shared position, if it belongs to an ally."""
    if slot is None or cambc.shared_memory.size() < 8:
        return None
    slots = _read_slots()
    carrier_slot = next((i for i, value in enumerate(slots[:ALERT_SLOT])
                         if value == MARKER), None)
    if carrier_slot is None or carrier_slot == slot:
        return None
    position = bytearray(2)
    cambc.shared_memory.read(6, position)
    tile = cambc.Vec2(position[0], position[1])
    if not game_map.is_in_bounds(tile):
        return None
    return carrier_slot, tile


def threat_active():
    """Return true when an ally recently saw an enemy near the carrier."""
    if cambc.shared_memory.size() <= ALERT_SLOT:
        return False
    value = bytearray(1)
    cambc.shared_memory.read(ALERT_SLOT, value)
    if value[0] == 0:
        return False
    reported_round = value[0] - 1
    age = (cambc.round_number() - reported_round) % 250
    return age <= ALERT_TTL

# E16 — Threat-only shared regroup

E16 starts from E13's active policy and restores G2's bank-any-positive-bag rule. Its only new coordination trigger is a two-round shared alert: any ally that sees an enemy within five tiles of the currently marked carrier records the alert in shared memory. Empty-bag teammates regroup to that carrier while the alert is fresh; outside danger, existing split farming and the single altar-approach escort remain.

This tests whether broadcasting confirmed danger closes E13's local-vision gap without making the whole team escort continuously. The alert uses a spare shared-memory byte; champion slots remain in bytes 0–4 and carrier coordinates in bytes 6–7. Status: unpromoted challenger.

# E43 — occupied-camp yield with E05A roster (rejected)

E43 started from E05A's Cassi & Issac / Stellar / Tavi roster and added only the temporary occupied-camp yield condition from E41. It kept the same unrestricted fallback when all candidate camps were occupied. The hypothesis was that this one cheap split-farm rule could improve the validated roster without changing its combat or banking policy.

The 32-match actual-cap pilot covered Corners, Interlock, Lanes and Packs, both sides, against G2, E05A, the carrier-hunter proxy and altar-denial proxy. All matches used `--fuel 100000` (2,500,000 Python fuel) and completed with zero bot faults.

| Opponent | Wins | E43 submitted | Opponent submitted | Net |
|---|---:|---:|---:|---:|
| G2 | 3/8 | 6,098 | 7,470 | -1,372 |
| E05A | 3/8 | 6,758 | 7,120 | -362 |
| Carrier hunter | 2/8 | 6,138 | 7,938 | -1,800 |
| Altar denial | 2/8 | 4,832 | 6,376 | -1,544 |
| **Total** | **10/32** | **23,826** | **28,904** | **-5,078** |

E43 is rejected. It lost against the direct E05A mirror and was worse across every opponent suite, including the three control opponents. The small rule did not produce enough gem throughput or enemy denial to offset camp-goal filtering. Preserve G2 and E05A unchanged. Exact runtime fuel was not exported by the runner.

Raw JSON results and the challenger source/build are included in this archive. All 32 replay bundles remain in `replays/E43_meta_occupied_camp_yield/`.

# E06 corrected-cap validation — Cassi & Issac pair-aware retreat threshold

Starting point: E05A's Cassi & Issac / Stellar / Tavi roster. The same G2 gameplay policy and draft order are retained. The only gameplay change is an earlier recall threshold for Cassi or Issac when they carry no gems: 50% health instead of the general 35%. Pair members carrying gems retain the existing behavior so they can bank promptly; all other champions remain unchanged.

Evidence prompting the test: E05A collected 17,886 gems versus G2's 17,748 but submitted 16,475 versus 16,602, with 394 versus 265 deaths. The linked Cassi/Issac pair contributed 196 death counts. Those end-of-match statistics do not identify death cause, so the hypothesis is that earlier retreat will reduce pair losses without costing too much farm time.

The original E06 records used the oversized Python budget (`--fuel 2500000`) and do not establish performance under the requested cap. This validation used `--fuel 100000`, the 2,500,000 Python fuel cap, across all nine maps and both sides against G2, the carrier hunter, altar denial and starter.

## Correct-cap result — rejected as a general upgrade

All 72 matches completed with zero faults:

| Opponent | E06 wins | E06 submitted / collected | E06 deaths | E05A wins | E05A submitted / collected | E05A deaths |
|---|---:|---:|---:|---:|---:|---:|
| G2 | 6/18 | 15,470 / 17,054 | 398 | 9/18 | 16,237 / 17,564 | 391 |
| Carrier hunter | 8/18 | 15,132 / 16,946 | 389 | 8/18 | 15,563 / 17,748 | 396 |
| Altar denial | 11/18 | 13,032 / 16,118 | 414 | 8/18 | 11,347 / 13,728 | 319 |
| Starter | 14/18 | 16,698 / 18,034 | 409 | 15/18 | 16,912 / 18,580 | 413 |

E06 improved the altar-denial score differential and win count, but lost score against the hunter and G2 and underperformed E05A against starter. Its linked pair recorded 202 deaths against G2, 194 against the hunter and 238 against altar denial; each exceeds E05A's corresponding pair total. The earlier retreat did not achieve its survival hypothesis. Keep G2 canonical and do not promote E06; retain it as evidence that the threshold can shift the altar matchup while worsening the broader profile.

# E24 — Varg and Vendetta draft order

E24 keeps G2 gameplay unchanged and changes only draft priority: select Tavi, Varg, Vendetta, then Ryth and Ren. Small maps therefore test the Varg/Vendetta pairing while preserving Tavi's field economy. This is a controlled roster-only test based on the user's report of leading teams using Varg and Vendetta.

Status: challenger pending full local benchmarks.

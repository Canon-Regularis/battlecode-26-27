# E47 — static mask cache

E47 caches walls, holes, altars and enemy spawn tiles once per match, then combines that static mask with fresh dynamic blockers for movement. It does not intentionally change the economic or combat strategy.

At the correct cap (`--fuel 100000` = 2,500,000 Python fuel), E47 and a profiling-only G2 control each ran against the carrier-hunter proxy on all nine maps and both sides. Each completed 18 matches with zero bot faults. Same instrumentation was used in both builds.

| Measure | G2 profiled control | E47 |
|---|---:|---:|
| Wins | 7/18 | 6/18 |
| Own submitted gems | 14,905 | 14,097 |
| Opponent submitted gems | 16,629 | 17,249 |
| Net gems | -1,724 | -3,152 |
| Mean per-match peak turn fuel | 1,420,686 | 1,182,260 |
| Highest sampled turn fuel | 1,663,211 | 1,649,056 |
| Bot faults | 0 | 0 |

The fuel samples favor E47, but the competitive sample does not show preserved score. Matches are unseeded and the profile uses `fuel_remaining()` reads and occasional stdout prints, so the fuel delta is indicative rather than paired-turn proof. Do not promote E47. G2 remains canonical. Full raw statistics are in `results/`; the profiling-only parent copy is `baseline_profiled/`.

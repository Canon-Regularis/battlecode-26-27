"""Dispatch draft and gameplay with the SDK template lifecycle."""
import cambc
import draft


def main():
    bot = None
    peak_turn_fuel = 0
    while True:
        try:
            if cambc.is_draft():
                draft.play()
            else:
                # Keep draft execution lightweight. The draft is a separate
                # runtime phase and must submit picks before gameplay modules
                # are imported.
                if bot is None:
                    from simple_policy import Bot
                    bot = Bot()
                fuel_at_start = cambc.fuel_remaining()
                bot.play_turn()
                used = fuel_at_start - cambc.fuel_remaining()
                if used > peak_turn_fuel:
                    peak_turn_fuel = used
                    print(f"LARP_PROFILE_SIMPLE|{cambc.round_number()}|{int(cambc.me().champion_name())}|fuel={used}|peak={peak_turn_fuel}", flush=True)
        except Exception as error:
            phase = "draft" if cambc.is_draft() else "turn"
            print(f"LARP_ERROR|{phase}|{cambc.round_number()}|{error}", flush=True)
        cambc.end_turn()


if __name__ == "__main__":
    main()

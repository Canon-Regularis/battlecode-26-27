# Varg Monster Strength challenger

E04 is a controlled shopping ablation copied from G2. Varg alone buys Monster Strength shards; all other champions keep Power Strength. The draft and gameplay policy are unchanged.

Hypothesis: the five-shard Monster emblem gives the same five Strength shard stats as before, then adds 10% camp damage; the Power emblem needs six shards for the extra stat and has no passive. This may shorten grouped camp clears and lower retaliation. The risk is that the sixth Power shard gives better general-purpose combat stats and the passive arrives too late.

This candidate is not promoted. `bots/larpbot` remains the champion.

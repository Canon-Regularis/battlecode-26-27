# E09 — Shared carrier rally beacon

Starting point: E05A's Cassi & Issac / Stellar / Tavi draft and G2 farming policy.

**Observation:** The user's meta read is that leading teams split for farming, then regroup to bank gems and enter dangerous areas. E08's visible-only rally heuristic had no aggregate gain; separated units cannot act on a carrier they cannot currently see.

**Hypothesis:** Use the team's eight shared bytes to broadcast the current rich carrier's location. Keep bytes 0–5 for individual camp assignments. While a unit carries at least 100 gems, its roster slot becomes a carrier marker and bytes 6–7 store its coordinates; the active rich carrier refreshes the beacon every turn, including while channeling. Other empty-bag units path to an adjacent tile and attack visible enemies near the reported carrier. When that carrier banks or dies, its marker clears. A second rich carrier can replace the marker on its next turn.

**Counterargument:** The beacon follows only one carrier at a time, can cause excessive escorting, and coordinate byte encoding assumes map coordinates fit in 0–254. The carrier's camp assignment is intentionally discarded while it carries a large bag and reacquired after banking.

**Evaluation:** local build plus all nine maps, both sides, at 2,500,000 fuel against both the unchanged E05A roster/policy and G2. Inspect wins, submitted/collected gems, deaths, faults and rally events. This remains experimental until it beats relevant opponents robustly.

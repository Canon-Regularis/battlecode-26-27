"""Shared carrier location beacon for rallying split farm routes."""

import cambc
from cambc import game_map


MARKER = 255
SLOT_COUNT = 6
MIN_CARRIER_GEMS = 100


def _read_slots():
    slots = bytearray(min(SLOT_COUNT, cambc.shared_memory.size()))
    cambc.shared_memory.read(0, slots)
    return slots


def update(me, slot):
    """Publish a rich carrier location or clear this unit's old beacon."""
    if slot is None or slot >= SLOT_COUNT or cambc.shared_memory.size() < 8:
        return
    slots = _read_slots()
    carrying = me.is_alive() and me.gem_count() >= MIN_CARRIER_GEMS
    if carrying:
        position = me.position()
        if position.x < 0 or position.y < 0 or position.x >= 255 or position.y >= 255:
            return
        for index, value in enumerate(slots):
            if value == MARKER:
                slots[index] = 0
        slots[slot] = MARKER
        cambc.shared_memory.write(0, slots)
        cambc.shared_memory.write(6, bytes((position.x, position.y)))
    elif slots[slot] == MARKER:
        slots[slot] = 0
        cambc.shared_memory.write(0, slots)
        cambc.shared_memory.write(6, b"\x00\x00")


def target(slot):
    """Return the current shared carrier (slot, position), if any."""
    if slot is None or cambc.shared_memory.size() < 8:
        return None
    slots = _read_slots()
    carrier_slot = next((index for index, value in enumerate(slots)
                         if value == MARKER), None)
    if carrier_slot is None or carrier_slot == slot:
        return None
    position = bytearray(2)
    cambc.shared_memory.read(6, position)
    tile = cambc.Vec2(position[0], position[1])
    if not game_map.is_in_bounds(tile):
        return None
    return carrier_slot, tile

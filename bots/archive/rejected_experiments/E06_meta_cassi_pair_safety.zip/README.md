# E06 — Cassi & Issac pair-aware retreat threshold

Starting point: E05A's Cassi & Issac / Stellar / Tavi roster. The same G2 gameplay policy and draft order are retained. The only gameplay change is an earlier recall threshold for Cassi or Issac when they carry no gems: 50% health instead of the general 35%. Pair members carrying gems retain the existing behavior so they can bank promptly; all other champions remain unchanged.

Evidence prompting the test: E05A collected 17,886 gems versus G2's 17,748 but submitted 16,475 versus 16,602, with 394 versus 265 deaths. The linked Cassi/Issac pair contributed 196 death counts. Those end-of-match statistics do not identify death cause, so the hypothesis is that earlier retreat will reduce pair losses without costing too much farm time.

Promotion gate: build; run both sides on all nine maps at 2,500,000 fuel against G2; compare wins, submitted/collected gems, deaths, gold and faults with E05A and G2. This is an unpromoted challenger.

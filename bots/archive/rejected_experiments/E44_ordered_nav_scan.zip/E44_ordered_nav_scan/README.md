# E44 — allocation-free nearest-step scan (rejected)

E44 started from E05A and changed only the nearest-step selection in `move_towards_closest`: it scans the origin and reachable steps in order, retaining the first minimum-distance candidate. This preserves the previous `min` tie behavior while removing the temporary combined list and callback. Fuel instrumentation measured candidate turn peaks; the strategy and draft were otherwise unchanged.

The actual-cap diagnostic ran four matches against the carrier-hunter proxy on Elkring and Expanse, both sides (`--fuel 100000`, 2,500,000 Python fuel). All completed without faults. E44 submitted 2,976 gems against 4,084; the score is a diagnostic sample and is not treated as a strategy comparison.

| Map | Candidate side | E44 measured peak | Earlier E35 sample |
|---|---|---:|---:|
| Elkring | A | 1,239,550 | 1,242,177 |
| Elkring | B | 1,239,285 | 1,242,088 |
| Expanse | A | 1,273,698 | 1,269,826 |
| Expanse | B | 1,289,982 | 1,285,446 |

These are small, mixed differences across separate runs, with fuel-read and champion/round instrumentation overhead. The highest observed E44 value was 1,289,982 (about 52% of the cap), slightly above E35's 1,285,446 sample. The runner has no direct statistics fuel field, and this sample does not establish a fuel reduction or worst-case margin. Reject as an unverified micro-optimization; preserve the original selector and G2. The four replay bundles remain under `replays/E44_ordered_nav_scan/`.

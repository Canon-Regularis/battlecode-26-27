# E30 — threat-avoiding route for rich carriers (rejected)

E30 started from G2 and added one conditional to the existing immediate-bank rule: a champion carrying at least 50 gems with a visible living enemy first tried a route that avoided tiles within the enemy's attack range plus two. If that route could not advance, it fell back to G2's normal route. Drafting, farming, combat, purchases, and retreat behavior stayed unchanged.

## Pilot results

Four maps (Corners, Interlock, Lanes, and Packs), both sides, against G2 and both pressure proxies: 24 matches at 2,500,000 fuel per turn. All matches built and completed with zero reported bot faults.

| Opponent | E30 wins | E30 submitted / collected | E30 deaths | Matched E27 pilot wins | E27 submitted / collected | E27 deaths |
|---|---:|---:|---:|---:|---:|---:|
| G2 | 4/8 | 7,770 / 8,144 | 106 | 5/8 | 7,330 / 7,698 | 98 |
| Carrier hunter | 3/8 | 7,138 / 7,556 | 115 | 4/8 | 7,426 / 8,246 | 126 |
| Altar denial | 4/8 | 5,938 / 6,640 | 76 | 5/8 | 5,862 / 6,688 | 86 |

The one route rule did not improve win count in any suite. Submission increased slightly against G2 and altar denial, but fell by 288 gems against the carrier hunter. Lower deaths in two proxy suites did not produce a broad score gain. Reject E30 and retain G2's simpler bank routing.

Raw statistics are in `results/`; replay bundles are under `replays/E30_safe_banking_route/`.

# E48 — 45% low-health retreat (rejected)

E48 starts from E41 and changes one number in `simple_policy.py`: the low-health recall trigger rises from 35% to 45% for every champion. The replay evidence showed Varg near death while empty-handed, but this broad threshold also sends other champions home earlier.

At `--fuel 100000` (2,500,000 Python fuel), E48 completed a four-map/two-side screen versus G2, the carrier-hunter proxy and altar-denial proxy (24 matches, zero faults).

| Opponent | E48 wins | E48 submitted / conceded | Net | Deaths | E41 wins | E41 submitted / conceded | Net | Deaths |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| G2 | 1/8 | 6,118 / 7,964 | -1,846 | 108 | 2/8 | 6,956 / 8,076 | -1,120 | 113 |
| Carrier hunter | 2/8 | 5,278 / 7,908 | -2,630 | 119 | 1/8 | 5,918 / 8,088 | -2,170 | 122 |
| Altar denial | 3/8 | 5,050 / 5,674 | -624 | 84 | 5/8 | 5,834 / 5,586 | +248 | 90 |

E48 reduced deaths slightly, but surrendered own submissions in every suite and lost the altar gains. Reject the global threshold; keep G2 canonical. The E48 source and 24 JSON results are archived at `bots/archive/rejected_experiments/E48_retreat_45.zip`; the 24 replays remain under `replays/E48_retreat_45/`.

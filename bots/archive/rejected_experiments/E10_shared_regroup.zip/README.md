# E10 — Active shared carrier regrouping

This challenger starts from G2's active `simple_policy` and keeps G2's draft,
combat priorities, shopping, camp loop, banking, recall and respawn handling.
The change is that a champion carrying at least 100 gems publishes its position
in shared memory; empty-bag allies rally to an adjacent tile and attack visible
enemies near the carrier.

The E08/E09 archives contain similar rally logic in `bot.py`, but their
`main.py` loads `simple_policy.Bot` instead. That means the archived benchmark
matrices did not execute their rally code; treat those results as inactive
controls, not evidence that regrouping failed. E10 places the behavior in the
active module path so its effect can be measured.

Build with `cambc build bots/challengers/E10_shared_regroup`. The first
evaluation uses both sides on Corners, Interlock, Lanes and Packs against the
unchanged G2 at 2,500,000 fuel per turn. Promote only after broader evidence.

# E45 — disable occupied-camp yield on Packs (rejected as a general upgrade)

E45 started from E41 and added one map gate: on Packs (31x31), use G2's unrestricted camp-goal set instead of skipping camp groups occupied by allies. Other maps retain E41's yield rule. The hypothesis came from the E41 Packs hunter pair: E41 had -710 net secured gems there, compared with G2's -434. The four-map pilot then ran Packs against G2, E41, the hunter and altar denial, both sides (8 matches, actual 2,500,000 Python fuel, zero faults).

| Packs opponent | Wins | E45 submitted | Opponent submitted | Net |
|---|---:|---:|---:|---:|
| G2 | 1/2 | 1,806 | 2,010 | -204 |
| E41 | 0/2 | 1,584 | 2,084 | -500 |
| Carrier hunter | 2/2 | 2,056 | 1,494 | +562 |
| Altar denial | 1/2 | 1,860 | 1,690 | +170 |

The Packs pressure signal justified a full actual-cap matrix: nine maps, both sides, vs G2, hunter and altar denial (54 matches; zero faults).

| Opponent | Wins | E45 submitted | Opponent submitted | Net | Deaths |
|---|---:|---:|---:|---:|---:|
| G2 | 7/18 | 14,760 | 17,137 | -2,377 | 276 |
| Carrier hunter | 6/18 | 13,682 | 17,089 | -3,407 | 318 |
| Altar denial | 9/18 | 12,732 | 12,549 | +183 | 263 |
| **Total** | **22/54** | **41,174** | **46,775** | **-5,601** | **857** |

Reject E45 as a general upgrade. It improved the Packs hunter pilot, but the full hunter suite remained one win and 1,659 net gems behind the correct-cap G2 baseline. Its altar suite improved on G2's 7/18 and -1,628, but did not retain E41's +417 net altar result (E45: +183). On the common four-map pilot, E45 beat E41's hunter win count (3/8 vs 1/8) but remained at -910 net; its altar wins tied E41's 5/8 and net was lower (+14 vs +248). The Packs two-side sample was not enough to override the broad result.

Keep G2 canonical and E41 only as the unpromoted altar specialist. The challenger source and relevant pilot/full-matrix results are archived here. All 62 local replay bundles remain under `replays/E45_pack_yield_gate/`.

# E42 — regroup on visible enemy contact (rejected)

E42 starts from E41's temporary camp-yield policy. It disables that yield while any enemy champion is visible, allowing empty-handed allies to converge on the ordinary nearest-camp goals under contact. The rest of E41/G2's policy is unchanged.

Built and screened at `--fuel 100000` (2,500,000 Python fuel). The full matrix covered nine maps and both sides against G2, the carrier hunter and altar denial (54 matches), plus a four-map/two-side E05A pilot (8 matches). All 62 matches completed with zero bot faults. The runner does not export fuel consumption.

| Opponent | Matches | Wins | E42 submitted | Opponent submitted | Net secured gems | E42 deaths |
|---|---:|---:|---:|---:|---:|---:|
| G2 | 18 | 7 | 15,082 | 17,061 | -1,979 | 279 |
| Carrier hunter | 18 | 5 | 13,276 | 17,719 | -4,443 | 327 |
| Altar denial | 18 | 7 | 12,336 | 12,791 | -455 | 257 |
| E05A | 8 | 5 | 7,336 | 6,624 | +712 | 105 |
| **Total** | **62** | **24** | **48,030** | **54,195** | **-6,165** | **968** |

The contact gate does not fix the hunter weakness. E42 trails G2's full hunter baseline by 2,695 net gems and two wins. It improves net differential by 1,173 against altar denial, but keeps only G2's 7/18 altar win count and underperforms E41's 9/18. Reject E42. Preserve E41 as the better altar specialist and G2 as canonical.

Raw statistics are in `results/`; replays remain under `replays/E42_regroup_on_contact/`.

# E22 — Safe 20-gem banking threshold

E22 starts from G2 and changes only the positive-bag banking trigger. It keeps farming while carrying fewer than 20 gems when no living enemy is visible within four tiles; it banks immediately at 20 gems or whenever that nearby danger condition is met. This tests whether a small efficiency gain from fewer altar trips can outweigh the extra carrier exposure. It does not add rallying, target assignment, or path scoring.

Status: exploratory challenger; do not promote until broad G2 and pressure comparisons support it.

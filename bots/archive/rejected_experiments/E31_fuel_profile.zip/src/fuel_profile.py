"""Temporary inclusive fuel high-water profiling for the G2 policy copy."""

import cambc

FUEL_PEAKS = {}


def profile_fuel(label):
    def decorate(function):
        def measured(*args, **kwargs):
            before = cambc.fuel_remaining()
            try:
                return function(*args, **kwargs)
            finally:
                after = cambc.fuel_remaining()
                used = before - after
                if used > FUEL_PEAKS.get(label, 0):
                    FUEL_PEAKS[label] = used
                    if label == "whole_turn":
                        peaks = ",".join(
                            f"{name}:{peak}"
                            for name, peak in sorted(FUEL_PEAKS.items())
                        )
                        # This is raised only after the policy has returned,
                        # so main.py catches it and ends the already-decided
                        # turn while exposing one diagnostic line to cambc.
                        raise RuntimeError(
                            f"FUEL_REPORT|{cambc.round_number()}|{used}|{after}|{peaks}"
                        )

        return measured

    return decorate

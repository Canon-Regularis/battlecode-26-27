# E23 — Nearby Varg carrier guard

E23 starts from G2. When Varg is healthy and empty-handed, and a visible enemy is within five tiles of a visible allied gem carrier, Varg moves to an adjacent tile if that carrier is within six tiles. If Varg is already adjacent, it holds position. It does not chase an enemy or rally the rest of the team; other champions keep farming. Existing attacks, including lethal carrier attacks, keep their G2 priority.

This isolates one nearby defensive regroup trigger from E17's offensive pursuit. Status: pilot pending.

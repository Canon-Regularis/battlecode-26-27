# E20 — Clear a blocking altar lock

E20 keeps G2 unchanged except for a banking fallback: when no unlocked altar is available and a visible enemy lock is the obstacle, a gem carrier attacks the nearest lock if already in range, otherwise it moves into attack range. It does not buy extra consumables or interrupt its farming route.

The intended trigger is narrow: spend attacks/movement to clear denial only when the carrier otherwise cannot bank. Status: unpromoted challenger.

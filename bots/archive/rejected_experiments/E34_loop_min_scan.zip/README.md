# E34 — explicit nearest-step scan

A core efficiency ablation based on E05A. In `move_towards_closest`, the challenger removes the temporary list and `min(..., key=field.get)` callback while preserving origin-first candidate order and the existing tie behavior. No strategic decision changed.

Built successfully. Eight mirrored matches against unchanged E05A on Corners, Interlock, Lanes, and Packs used `--fuel 100000` (2,500,000 Python fuel) and completed with zero bot faults. E34 scored 5/8, submitting 6,930 gems with 140 deaths; E05A submitted 6,184 gems with 146 deaths. This is a small screen against the same policy, not a matched comparison to the historical E05A baseline, so the result does not establish a competitive gain. CAMBC exports no per-turn fuel metric; the 256-byte artifact-size reduction is not evidence of lower runtime fuel. Reject as unverified. G2 remains unchanged.

# E15 — In-range carrier attack priority

E15 is G2 with one conditional change: after any immediately lethal carrier attack, choose an in-range enemy gem carrier before another enemy champion. It uses the same attack action the baseline would already spend and does not chase, rally, or add pathfinding.

Hypothesis: damaging a carrier may improve the chance of denying carried gems or forcing an early bank without reducing farm movement. Status: unpromoted challenger; evaluate against G2 and the local carrier-hunter proxy.

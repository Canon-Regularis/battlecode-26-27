# E46 — yield camps only to empty-handed allies

E46 starts from E41 and changes one condition in its temporary split-farm rule: a visible ally reserves a camp group only while carrying zero gems. A loaded ally is already heading to bank, so its camp group remains available to other farmers. The fallback, movement, combat, banking, retreat and draft policies are unchanged.

Hypothesis: this keeps farmers spread across camps but avoids a stale reservation during the ally's bank trip. The actual-cap screen used `--fuel 100000` on Corners, Interlock, Lanes and Packs, both sides, against G2, E05A, the carrier hunter, altar denial and E41 (40 matches; all zero faults).

| Opponent | Matches | Wins | E46 submitted | Opponent submitted | Net | Deaths |
|---|---:|---:|---:|---:|---:|---:|
| G2 | 8 | 2 | 6,956 | 8,076 | -1,120 | 113 |
| E05A | 8 | 4 | 7,030 | 7,096 | -66 | 105 |
| Carrier hunter | 8 | 1 | 5,918 | 8,088 | -2,170 | 122 |
| Altar denial | 8 | 5 | 5,834 | 5,678 | +156 | 91 |
| E41 | 8 | 4 | 7,412 | 7,412 | 0 | 112 |
| **Total** | **40** | **16** | **33,150** | **36,350** | **-3,200** | **543** |

Reject E46. Against G2, E05A and the carrier hunter, it exactly matches E41's corresponding four-map totals; its altar net is 92 gems below E41's matched pilot, and the direct E41 mirror is score-neutral. The loaded-ally distinction did not produce a measurable coordination or hunter-survival gain. Keep E41 only as the existing altar specialist and keep G2 canonical. All tests were local.

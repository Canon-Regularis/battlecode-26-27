# E12 — Fast split-bank with a rotating escort

E12 starts from G2 and holds each bag only to 20 gems, banking sooner on low
health, a nearby enemy, or altar range. A rich carrier advertises its position;
normally just the next roster slot escorts it, leaving the rest of the team to
farm. If an ally sees an enemy within five tiles of the carrier, that ally also
converges to support.

This ablates E11's all-empty-units rally, which risked abandoning too much farm
tempo. E08/E09 were not active-policy tests; see E10 for the entry-point audit.
Evaluate against G2 and the carrier-hunter / altar-denial proxies before any
promotion decision.

"""Tiny shared-memory beacon for escorting one rich gem carrier."""

import cambc
from cambc import game_map


MARKER = 255
SLOT_COUNT = 6
MIN_CARRIER_GEMS = 20


def _read_slots():
    slots = bytearray(min(SLOT_COUNT, cambc.shared_memory.size()))
    cambc.shared_memory.read(0, slots)
    return slots


def update(me, slot):
    """Publish a rich carrier position, or clear this unit's stale marker."""
    if slot is None or slot >= SLOT_COUNT or cambc.shared_memory.size() < 8:
        return
    slots = _read_slots()
    carrying = me.is_alive() and me.gem_count() >= MIN_CARRIER_GEMS
    if carrying:
        position = me.position()
        if not (0 <= position.x < 255 and 0 <= position.y < 255):
            return
        for index, value in enumerate(slots):
            if value == MARKER:
                slots[index] = 0
        slots[slot] = MARKER
        cambc.shared_memory.write(0, slots)
        cambc.shared_memory.write(6, bytes((position.x, position.y)))
    elif slots[slot] == MARKER:
        slots[slot] = 0
        cambc.shared_memory.write(0, slots)
        cambc.shared_memory.write(6, b"\x00\x00")


def target(slot):
    """Read the current carrier's shared position, if it belongs to an ally."""
    if slot is None or cambc.shared_memory.size() < 8:
        return None
    slots = _read_slots()
    carrier_slot = next((i for i, value in enumerate(slots) if value == MARKER), None)
    if carrier_slot is None or carrier_slot == slot:
        return None
    position = bytearray(2)
    cambc.shared_memory.read(6, position)
    tile = cambc.Vec2(position[0], position[1])
    if not game_map.is_in_bounds(tile):
        return None
    return carrier_slot, tile

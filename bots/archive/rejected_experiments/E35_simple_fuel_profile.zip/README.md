# E35 — active-policy fuel profile (diagnostic only)

Copied E05A and wrapped the active `simple_policy.Bot.play_turn()` with `fuel_remaining()` reads. The match policy is otherwise unchanged. At the actual 2,500,000 Python fuel cap, four carrier-hunter matches on Elkring and Expanse completed with zero faults. The highest logged per-champion turn consumption was 1,285,446 at Expanse Team B, Issac, round 31. Elkring peaks were 1,242,177 and 1,242,088; Expanse Team A peaked at 1,269,826.

This sample includes the start/end fuel API reads and champ/round reads, excludes the peak `print` and outer `end_turn`, and is not a whole-map worst-case guarantee. Diagnostic match score differences are not treated as strategy results. Raw stats and source are archived; replay bundles (including stdout traces) remain under `replays/E35_simple_fuel_profile/`.

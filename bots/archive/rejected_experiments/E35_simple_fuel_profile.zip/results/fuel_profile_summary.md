# E35 fuel profile sample

| Match side | Champion | Round | Used fuel |
|---|---|---:|---:|
| Elkring A | Varg | 22 | 1,242,177 |
| Elkring B | Varg | 22 | 1,242,088 |
| Expanse A | Issac | 31 | 1,269,826 |
| Expanse B | Issac | 31 | 1,285,446 |

Per-turn cap: 2,500,000 Python fuel (`--fuel 100000`). Values include fuel-measurement reads but exclude the peak log print and outer `cambc.end_turn()` call. Four-run sample only; not a worst-case audit.

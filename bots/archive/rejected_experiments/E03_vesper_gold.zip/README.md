# Vesper gold challenger

E03 is a controlled draft experiment copied from G2. The only strategy change is champion pick priority: Vesper replaces Ren in the third slot; remaining priority is otherwise kept in order. Gameplay, shopping and target selection are unchanged.

Hypothesis: Vesper's documented +20% gold passive may fund enough additional Strength upgrades to offset Ren's dash and retaliation. Test on Corners and Interlock with both sides versus G2. This is an unpromoted candidate; `bots/larpbot` remains the champion.

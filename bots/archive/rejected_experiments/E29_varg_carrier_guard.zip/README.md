# E29 — Tavi guards a threatened Varg carrier

E29 starts from E27. The only added behavior is that empty-bag Tavi moves beside a visible Varg carrying at least 50 gems when a visible enemy is within five tiles of Varg. Otherwise, E27's one-capturer rule and G2's bank/farm policy remain unchanged.

## Results

Built successfully; 32 matches across Corners, Interlock, Lanes and Packs, both sides, against G2, E27, the carrier hunter and altar denial. All matches used 2,500,000 fuel per turn and completed with zero reported faults.

Against G2 and both pressure proxies, all 24 matching statistics files are byte-for-byte identical to E27's pilot files. Against E27 directly, the result was 4/8, with both teams submitting 7,452 gems, collecting 7,976 and recording 105 deaths.

## Decision

Reject as no measurable improvement. Do not expand to a full matrix. Source and statistics are archived at `bots/archive/rejected_experiments/E29_varg_carrier_guard.zip`; replays remain in `replays/E29_varg_carrier_guard/`.

# E13 — Altar approach guard

E13 keeps E12's 20-gem cap and fast safety banking, but only sends its rotating
single guard to a carrier when the carrier is within two tiles of an altar. Any
empty-bag ally that sees an enemy within five tiles of the carrier can still
converge to fight. Otherwise the team continues its split-farm routes.

This tests whether protecting the final bank approach preserves E12's survival
gain without paying an escort cost throughout the farming cycle. It remains an
unpromoted local challenger.

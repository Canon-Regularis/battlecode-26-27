"""Starter-derived Stage 1 policy used as a controlled challenger.

This deliberately keeps the objective loop small: attack visible camps, move to
the nearest available camp tiles with the SDK navigator, and bank any gems.
The module is independent from the persistent ObjectivePolicy so benchmark
results can separate navigation/state-machine effects from champion picks.
"""

import cambc
from cambc import game_map
from randomness import below
import rally

from combat import clear_turn


Team = cambc.Team
Item = cambc.ItemType
PURCHASE_SHARD = Item.POWER_SHARD_OF_STRENGTH
BANK_THRESHOLD = 20


def tiles_around(position, radius):
    tiles = cambc.Bitboard()
    tiles.draw_chebyshev(position, radius)
    return tiles


def blocked_tiles(me):
    blocked = (game_map.walls() | game_map.holes() | game_map.altars()
               | game_map.spawn_region(Team.ENEMY) | cambc.vision.champion_tiles()
               | cambc.vision.camp_tiles() | cambc.vision.teleport_tiles())
    blocked.set(me.position(), False)
    return blocked


def move_towards_closest(me, goals):
    origin = me.position()
    if not me.can_move() or goals.is_set(origin):
        return False
    blocked = blocked_tiles(me)
    camp_tiles = cambc.vision.camp_tiles()
    goals &= ~blocked | camp_tiles
    if goals.is_empty():
        return False
    if goals.count() == 1:
        goal = goals.positions()[0]
        if not blocked.is_set(goal):
            try:
                return me.move_towards(goal)
            except cambc.Error:
                return False

    field = cambc.DistanceField()
    origin_mask = cambc.Bitboard()
    origin_mask.set(origin)
    field.compute_to(blocked & ~goals, goals, origin_mask, cambc.Bitboard())
    reachable = blocked.reachable_tiles(origin, me.base_stats().base_move_speed)
    step = min([origin, *reachable.positions()], key=field.get)
    if step == origin:
        return False
    try:
        return me.move_absolute(step)
    except cambc.Error:
        return False


class Bot:
    """Small benchmark challenger with starter turn ordering."""

    def __init__(self):
        self.groups = None
        self.group_masks = {}
        self.all_spawn_tiles = cambc.Bitboard()
        self.respawn_until = {}
        self.slot = None
        self.roster_count = 0
        self._slot_initialized = False

    def initialize_slot(self, me):
        if self._slot_initialized:
            return
        data = bytes(cambc.draft_memory)
        if len(data) >= 4 and data[:3] == b"LB2":
            count = data[3]
            self.roster_count = count
            try:
                self.slot = data[4:4 + count].index(int(me.champion_name()))
            except ValueError:
                self.slot = None
        self._slot_initialized = True

    def ensure_groups(self):
        if self.groups is not None:
            return
        self.groups = game_map.camp_groups()
        self.group_masks = {int(group): group.spawn_tiles() for group in self.groups}
        for mask in self.group_masks.values():
            self.all_spawn_tiles |= mask

    def buy_shard(self, me):
        item = PURCHASE_SHARD
        count = me.gold_count() // item.cost()
        if count and me.can_buy(item, count):
            me.buy(item, count)

    def available_camp_goals(self):
        self.ensure_groups()
        goals = cambc.Bitboard()
        respawning_tiles = cambc.Bitboard()
        visible = cambc.vision.visible_tiles()
        round_number = cambc.round_number()
        for group in self.groups:
            key = int(group)
            mask = self.group_masks[key]
            status = None
            if not (mask & visible).is_empty():
                try:
                    status = group.state()
                except cambc.Error:
                    status = None
            if isinstance(status, game_map.CampGroupRespawning):
                self.respawn_until[key] = round_number + max(1, status.timer) + 1
                respawning_tiles |= mask
                continue
            if isinstance(status, (game_map.CampGroupAlive, game_map.CampGroupRewardAvailable)):
                self.respawn_until.pop(key, None)
            elif self.respawn_until.get(key, -1) >= round_number:
                # Keep a previously observed respawn out of navigation goals
                # after vision is lost, so we do not stand on its spawn tiles.
                respawning_tiles |= mask
                continue
            else:
                self.respawn_until.pop(key, None)
            goals |= mask
        goals &= ~respawning_tiles
        return goals, respawning_tiles

    def current_respawning_tiles(self, me):
        """Refresh only camp state relevant to our current tile before banking."""
        self.ensure_groups()
        current = me.position()
        if not self.all_spawn_tiles.is_set(current):
            return cambc.Bitboard()
        visible = cambc.vision.visible_tiles()
        round_number = cambc.round_number()
        result = cambc.Bitboard()
        for group in self.groups:
            key = int(group)
            mask = self.group_masks[key]
            known_until = self.respawn_until.get(key, -1)
            if mask.is_set(current) and not (mask & visible).is_empty():
                try:
                    status = group.state()
                except cambc.Error:
                    status = None
                if isinstance(status, game_map.CampGroupRespawning):
                    known_until = round_number + max(1, status.timer) + 1
                    self.respawn_until[key] = known_until
                elif isinstance(status, (game_map.CampGroupAlive, game_map.CampGroupRewardAvailable)):
                    self.respawn_until.pop(key, None)
                    known_until = -1
            if known_until >= round_number:
                result |= mask
        return result

    def vacate_respawning_tile(self, me, respawning_tiles, goals):
        current = me.position()
        if not me.can_move() or not respawning_tiles.is_set(current):
            return False
        blocked = blocked_tiles(me) | respawning_tiles
        candidates = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                tile = cambc.Vec2(current.x + dx, current.y + dy)
                if (game_map.is_in_bounds(tile) and not blocked.is_set(tile)):
                    candidates.append(tile)
        if not candidates:
            return False
        goal_positions = goals.positions()
        if not goal_positions:
            candidates.sort(key=lambda tile: (tile.y, tile.x))
        else:
            candidates.sort(key=lambda tile: (
                min(tile.chebyshev_distance(goal) for goal in goal_positions),
                tile.y, tile.x
            ))
        try:
            return me.move_absolute(candidates[0])
        except cambc.Error:
            return False

    def farm(self, me, goals):

        camps = cambc.vision.camps()
        if clear_turn(me, camps, None):
            return
        if move_towards_closest(me, goals):
            # Melee champions can move and attack in one turn; refresh vision
            # after the move and take the newly available attack when possible.
            if me.can_attack():
                clear_turn(me, cambc.vision.camps(), None)

    def bank(self, me):
        current = me.position()
        goals = cambc.Bitboard()
        for altar in game_map.altars().positions():
            if cambc.vision.has_altar_lock(altar):
                continue
            if current.chebyshev_distance(altar) <= cambc.constants.SUBMIT_GEMS_RANGE:
                try:
                    return me.submit_gems(altar)
                except cambc.Error:
                    return False
            goals |= tiles_around(altar, cambc.constants.SUBMIT_GEMS_RANGE)
        return move_towards_closest(me, goals)

    def play_turn(self):
        me = cambc.me()
        self.initialize_slot(me)
        rally.update(me, self.slot)
        if not me.is_alive() or me.is_recalling() or me.is_submitting_gems() or me.is_teleporting():
            return

        at_spawn = game_map.spawn_region(Team.ALLY).is_set(me.position())
        carrying_gems = me.gem_count() > 0
        needs_retreat = not at_spawn and me.health() < me.max_health() * 0.35
        if carrying_gems or needs_retreat:
            respawning_tiles = self.current_respawning_tiles(me)
            if respawning_tiles.is_set(me.position()):
                route_goals = cambc.Bitboard()
                if carrying_gems:
                    for altar in game_map.altars().positions():
                        if not cambc.vision.has_altar_lock(altar):
                            route_goals.set(altar)
                else:
                    route_goals = game_map.spawn_region(Team.ALLY)
                if self.vacate_respawning_tile(me, respawning_tiles, route_goals):
                    return
                # Do not start tribute or recall on a respawn tile if every
                # local exit is temporarily blocked; retry the exit next turn.
                return

        if at_spawn or me.champion_name() == cambc.ChampionType.TAVI:
            self.buy_shard(me)

        # A shallow retreat threshold matches the starter's demonstrated
        # survival behavior while avoiding larpbot's earlier 45% retreat loop.
        if needs_retreat:
            try:
                me.recall()
                return
            except cambc.Error:
                pass

        enemies = cambc.vision.champions(Team.ENEMY)
        if me.gem_count() > 0:
            current = me.position()
            threatened = False
            for enemy in enemies:
                try:
                    if (enemy.is_visible() and enemy.health() > 0
                            and current.chebyshev_distance(enemy.position()) <= 5):
                        threatened = True
                        break
                except cambc.Error:
                    continue
            near_altar = any(
                current.chebyshev_distance(altar) <= cambc.constants.SUBMIT_GEMS_RANGE
                for altar in game_map.altars().positions()
            )
            if (me.gem_count() >= BANK_THRESHOLD or needs_retreat
                    or threatened or near_altar):
                self.bank(me)
                return

        if me.can_attack():
            attack_tiles = me.attack_tiles()
            lethal_carriers = []
            for enemy in enemies:
                try:
                    if (enemy.is_visible() and enemy.health() > 0
                            and enemy.gem_count() > 0
                            and enemy.health() <= me.strength()
                            and attack_tiles.is_set(enemy.position())):
                        lethal_carriers.append((enemy, enemy.gem_count(), enemy.health()))
                except cambc.Error:
                    continue
            if lethal_carriers:
                target = min(lethal_carriers,
                             key=lambda item: (-item[1], item[2], int(item[0])))
                try:
                    me.attack(target[0])
                    return
                except cambc.Error:
                    pass

            # Preserve the established target order unless a gem carrier can
            # actually be killed by this attack.
            for enemy in enemies:
                try:
                    if (enemy.is_visible() and enemy.health() > 0
                            and attack_tiles.is_set(enemy.position())):
                        me.attack(enemy)
                        return
                except cambc.Error:
                    continue

        # Bankers publish their live location. Empty-bag teammates rally to an
        # adjacent tile and protect the carrier's altar approach instead of
        # starting a disconnected farm route.
        if me.gem_count() == 0 and not at_spawn:
            beacon = rally.target(self.slot)
            if beacon is not None:
                carrier_slot, carrier_position = beacon
                threatened = False
                for enemy in enemies:
                    try:
                        if (enemy.is_visible() and enemy.health() > 0
                                and enemy.position().chebyshev_distance(carrier_position) <= 5):
                            threatened = True
                            break
                    except cambc.Error:
                        continue
                entering_altar_range = any(
                    carrier_position.chebyshev_distance(altar) <= 2
                    for altar in game_map.altars().positions()
                )
                escort_slot = (carrier_slot + 1) % max(1, self.roster_count)
                if not threatened and (not entering_altar_range or self.slot != escort_slot):
                    beacon = None
            if beacon is not None:
                _, carrier_position = beacon
                attack_tiles = me.attack_tiles() if me.can_attack() else None
                if attack_tiles is not None:
                    for enemy in enemies:
                        try:
                            if (enemy.is_visible() and enemy.health() > 0
                                    and enemy.position().chebyshev_distance(carrier_position) <= 5
                                    and attack_tiles.is_set(enemy.position())):
                                me.attack(enemy)
                                return
                        except cambc.Error:
                            continue
                if me.position().chebyshev_distance(carrier_position) <= 1:
                    return
                escort_goals = tiles_around(carrier_position, 1)
                escort_goals.set(carrier_position, False)
                if move_towards_closest(me, escort_goals):
                    return

        camp_goals, _ = self.available_camp_goals()
        self.farm(me, camp_goals)
        # Match the starter's randomized intra-team processing order. With
        # several champions selecting the same nearby camp, rotating priority
        # avoids a fixed roster-order advantage every round.
        me.set_priority(1 + below(100))

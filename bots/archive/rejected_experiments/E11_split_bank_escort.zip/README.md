# E11 — Split farm, then escorted bank

E11 keeps G2's draft, combat and camp navigation, but carries an individual
bag up to 40 gems before routing to an altar. It banks earlier when the carrier
is below the existing retreat-health threshold, sees an enemy within five
tiles, or is already in submission range. At 40 gems, the carrier publishes
its position through shared memory and empty-bag teammates rally to an adjacent
tile, attacking visible enemies near the carrier when possible.

This is the first active regrouping candidate. E08/E09's archived rally code
was unreachable from their `main.py`, and E10's 100-gem trigger produced
byte-identical G2 outcomes because the active policy banks small bags. E11
tests both the holding threshold and escort behavior together; neither should
be promoted without broad map/side evidence and pressure testing.

Build with `cambc build bots/challengers/E11_split_bank_escort`. Local
statistics go in `results/`; replay bundles go in `replays/E11_split_bank_escort/`.

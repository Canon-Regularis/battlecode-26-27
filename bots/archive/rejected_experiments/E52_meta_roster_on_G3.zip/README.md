# E52 — E05A meta roster on G3 gameplay

Starting from promoted G3, E52 changes only draft priority to the E05A order: Cassi & Issac, Stellar, Tavi, followed by Vendetta and Varg when additional picks are available. All gameplay policy and combat code match G3.

The hypothesis is that the observed top-team roster improves farm coverage and camp clearing on top of G3's simpler empty-handed behavior. Test all nine maps and both sides against G2, the carrier hunter and altar denial at `--fuel 100000` (2,500,000 Python fuel). Compare secured gems, denial, wins and deaths to E51/G3.

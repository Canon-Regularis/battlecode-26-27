# E17 — Conditional Varg carrier intercept

E17 keeps G2's farm, banking, draft and combat rules. It adds one pressure response: when healthy and empty-handed, Varg moves toward a visible enemy gem carrier only if that enemy is within five tiles of a visible allied gem carrier. Other champions continue the existing policy. A lethal enemy-carrier attack remains the highest priority.

This tests a one-body counter-hunt trigger that ties pursuit to immediate bag protection, rather than sending the whole team after every visible carrier. Status: unpromoted challenger.

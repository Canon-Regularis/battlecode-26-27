# E26 — one Varg Durability Health shard

E26 starts from G2. The only policy change is the first shop purchase for Varg: buy one `DURABILITY_SHARD_OF_HEALTH`, then use G2's existing Power Strength purchase rule. Draft, navigation, combat, capture, retreat and banking are unchanged.

## Result

Built successfully and ran all nine maps on both sides against G2, the carrier-hunter proxy and the altar-denial proxy (54 matches total). Every match used 2,500,000 fuel per turn. All completed with zero bot faults. Varg purchased exactly one Health shard in each match.

| Opponent | Wins | E26 submitted / collected | Comparison | Deaths |
|---|---:|---:|---|---:|
| G2 | 8/18 | 16,492 / 17,626 | G2 in these games: 10/18 and 17,051 / 18,272 | 270 vs 264 |
| Carrier hunter | 7/18 | 15,156 / 17,068 | G2 full baseline: 6/18 and 15,461 / 16,614 | 299 vs 274 |
| Altar denial | 11/18 | 13,098 / 14,532 | G2 full baseline: 9/18 and 13,437 / 14,790 | 205 vs 205 |

## Decision

Reject. E26 gains proxy wins but submits fewer gems in both pressure matrices, and loses the direct G2 matrix by 559 gems. Keep G2's Strength-only build canonical. Raw match statistics are in `results/`; replays are under `replays/E26_varg_durability/`.

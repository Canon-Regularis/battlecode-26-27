# E21 — Varg altar-approach guard

E21 is E13 with one coordination change: Varg is the designated single escort when a carrier is within two tiles of an altar. The guard remains conditional on the bank approach; split farming continues elsewhere, and visible threats still cause nearby teammates to converge.

Hypothesis: Varg's strength, durability and splash make him a better fixed guard than E13's rotating champion slot, while preserving the same farm routes and banking threshold. Status: unpromoted challenger.

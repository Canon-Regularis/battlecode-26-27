# E40 — three-way camp split (rejected)

E40 starts from G2 and changes only farm-goal selection. Each champion selects camp groups whose engine handle modulo three matches its own handle modulo three. If that partition has no available groups, it falls back to all available groups. Banking, combat, draft, and navigation are unchanged.

At `--fuel 100000` (2,500,000 Python fuel), E40 completed a 32-match pilot: Corners, Interlock, Lanes, and Packs; both sides; opponents G2, E05A, carrier hunter, and altar denial. There were zero bot faults.

| Opponent | Wins | Submitted by E40 | Submitted by opponent | Net secured gems | E40 deaths |
|---|---:|---:|---:|---:|---:|
| G2 | 0/8 | 5,428 | 8,152 | -2,724 | 103 |
| E05A | 2/8 | 5,324 | 7,532 | -2,208 | 102 |
| Carrier hunter | 2/8 | 5,274 | 7,774 | -2,500 | 123 |
| Altar denial | 1/8 | 4,218 | 6,238 | -2,020 | 93 |
| Total | 5/32 | 20,244 | 29,696 | -9,452 | 421 |

Reject the hard modulo partition. Its only two wins against G2, hunter and E05A came from a narrow Lanes/Pack signal; the full screen lost 9,452 secured gems and never beat G2. The simpler lesson is to preserve G2's unrestricted nearest-available-goal selection. Future split-farm experiments should add a small, temporary preference only when an ally is already working the same camp, and fall back immediately when alternatives are unavailable.

Raw JSON results are in `results/`. All 32 replay bundles remain in `replays/E40_three_way_camp_split/`.

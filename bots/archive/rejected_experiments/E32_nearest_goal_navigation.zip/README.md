# E32 — Nearest-goal navigation

E32 starts from E05A: Cassi & Issac / Stellar / Tavi and the same farm, capture, combat and banking policy. Its only gameplay change is movement target selection. Instead of building a distance field over every goal and reachable tile, it picks the geometrically nearest goal tile and asks the SDK navigator for a shortest legal path to it.

**Hypothesis:** removing the Python-side multi-goal field and reachable-tile scan will reduce work per movement decision while preserving the efficient split-farming core.

**Counterargument:** the geometrically nearest goal may be behind an obstacle or otherwise costly to reach, so target choice can reduce secured gems even though route execution remains shortest-path.

## Result — rejected

At `--fuel 100000` (2,500,000 Python fuel), E32 completed an eight-match pilot on Corners, Interlock, Lanes and Packs, both sides, against E05A with zero faults. It won 1/8 and submitted 3,160 gems / collected 3,422, with 87 deaths. E05A submitted 7,680 / collected 8,212, with 140 deaths. The reduction in deaths did not come close to repaying lost farming throughput.

An initial implementation allowed occupied camp tiles as goals, which the SDK navigator could not enter; that build produced no activity on its first pilot. The completed pilot above filters blocked goals. This corrected version is still a clear economic regression, so it was not expanded against the pressure proxies. Its per-turn fuel savings were not measured; match completion only confirms the cap was not exceeded.

Keep E32 archived as a failed simplification experiment. G2 remains canonical, and E05A remains the strongest pressure-roster challenger.

# E50 — Varg-only retreat threshold at 45% (rejected)

E50 started from E41 and changed one threshold: Varg retreats below 45% health, while other champions remain at 35%. It tested whether E49's Varg-only 40% threshold was simply too late to prevent the observed Packs hunter death.

The actual-cap run (`--fuel 100000`, 2,500,000 Python fuel) covered all nine maps and both sides against the carrier-hunter and altar-denial proxies: 36 matches, zero bot faults.

| Opponent | Wins | Own submitted | Opponent submitted | Net | Deaths |
|---|---:|---:|---:|---:|---:|
| Carrier hunter | 1/18 | 11,860 | 18,227 | -6,367 | 315 |
| Altar denial | 3/18 | 9,792 | 14,657 | -4,865 | 248 |

Reject E50. The result is materially worse than E49's already rejected full-matrix result (4/18, -5,627 vs hunter; 9/18, -463 vs altar). Runs were unseeded, so this is not a paired causal estimate. Preserve the compact G2 core and require a specific repeated replay failure before adding another survival condition.

Raw match JSON is included here. Replay bundles remain at `replays/E50_varg_retreat_45/`.

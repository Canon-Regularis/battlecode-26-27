# E25 — Tavi emergency stun

E25 starts from G2. It adds one defensive action: when Tavi has her slot-1 stun ready, she stuns a visible enemy that is either actively submitting gems or within five tiles of a visible allied gem carrier. The enemy must be in the ability's legal target tiles. No unit moves to guard or chase; all other policy remains G2.

The rule tests a documented, high-value interruption with no added route planning. Status: challenger pending local benchmarks.
